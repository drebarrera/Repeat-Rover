import modules as mx

### OBJECTS ###
alert = mx.C()
alertText = mx.T()

### CONTENT ###
alert.content = [alertText]

### PROPERTIES ###
alert.id = 'alert'
alert.background_color = 'rgba(255, 255, 255, 0.9)'
alertText.id = 'alertText'