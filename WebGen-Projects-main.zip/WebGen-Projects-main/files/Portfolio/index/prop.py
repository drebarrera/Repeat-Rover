class info:
    def __init__(self):
        self.restrictions = True