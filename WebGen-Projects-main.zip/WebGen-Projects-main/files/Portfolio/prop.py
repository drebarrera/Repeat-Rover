class info:
    def __init__(self):
        self.restrictions = Trueclass info:
    def __init__(self):
        self.restrictions = True